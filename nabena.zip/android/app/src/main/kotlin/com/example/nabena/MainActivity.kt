package com.example.nabena

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
