import 'package:flutter/material.dart';
import '../models/settings.dart';
import '../services/settings_service.dart';

class AppStateProvider with ChangeNotifier {
  final SettingsService _settingsService = SettingsService.instance;
  late UserSettings _settings;
  bool _isDarkMode = false;
  bool _isLoading = true;

  AppStateProvider() {
    _loadSettings();
  }

  bool get isDarkMode => _isDarkMode;
  bool get isLoading => _isLoading;
  UserSettings get settings => _settings;

  Future<void> _loadSettings() async {
    _settings = await _settingsService.loadSettings();
    _isDarkMode = _settings.darkMode;
    _isLoading = false;
    notifyListeners();
  }

  Future<void> updateSettings(UserSettings newSettings) async {
    _settings = newSettings;
    await _settingsService.saveSettings(newSettings);
    notifyListeners();
  }

  Future<void> toggleDarkMode() async {
    _isDarkMode = !_isDarkMode;
    final newSettings = _settings.copyWith(darkMode: _isDarkMode);
    await updateSettings(newSettings);
  }

  Future<void> updateFontSize(double size) async {
    final newSettings = _settings.copyWith(fontSize: size);
    await updateSettings(newSettings);
  }

  Future<void> updateQuranReciter(String reciter) async {
    final newSettings = _settings.copyWith(quranReciter: reciter);
    await updateSettings(newSettings);
  }

  Future<void> updateLanguage(String language) async {
    final newSettings = _settings.copyWith(selectedLanguage: language);
    await updateSettings(newSettings);
  }

  Future<void> toggleNotifications(bool enabled) async {
    final newSettings = _settings.copyWith(notificationsEnabled: enabled);
    await updateSettings(newSettings);
  }

  Future<void> addBookmark(String bookmark) async {
    final List<String> updatedBookmarks = [..._settings.bookmarks, bookmark];
    final newSettings = _settings.copyWith(bookmarks: updatedBookmarks);
    await updateSettings(newSettings);
  }

  Future<void> removeBookmark(String bookmark) async {
    final List<String> updatedBookmarks =
        _settings.bookmarks.where((b) => b != bookmark).toList();
    final newSettings = _settings.copyWith(bookmarks: updatedBookmarks);
    await updateSettings(newSettings);
  }

  Future<void> updateKhatmahDays(int days) async {
    final newSettings = _settings.copyWith(remainingKhatmahDays: days);
    await updateSettings(newSettings);
  }

  Future<void> updateLastReadPage(int page) async {
    final newSettings = _settings.copyWith(lastReadPage: page);
    await updateSettings(newSettings);
  }

  ThemeData get theme {
    return _isDarkMode
        ? ThemeData.dark().copyWith(
            primaryColor: Colors.teal,
            colorScheme: const ColorScheme.dark(primary: Colors.teal),
          )
        : ThemeData.light().copyWith(
            primaryColor: Colors.teal,
            colorScheme: const ColorScheme.light(primary: Colors.teal),
          );
  }
}
