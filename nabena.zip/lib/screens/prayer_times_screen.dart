import 'package:flutter/material.dart';
import '../services/prayer_service.dart';
import 'package:adhan/adhan.dart';
import 'package:hijri/hijri_calendar.dart';

class PrayerTimesScreen extends StatefulWidget {
  const PrayerTimesScreen({super.key});

  @override
  State<PrayerTimesScreen> createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen> {
  PrayerTimes? _prayerTimes;
  String _nextPrayer = '';
  Duration _timeUntilNextPrayer = Duration.zero;
  String _hijriDate = '';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadPrayerTimes();
    _updateHijriDate();
  }

  void _updateHijriDate() {
    final hijri = HijriCalendar.now();
    setState(() {
      _hijriDate = '${hijri.hDay} ${hijri.getLongMonthName()} ${hijri.hYear}';
    });
  }

  Future<void> _loadPrayerTimes() async {
    try {
      final prayerTimes = await PrayerService.instance.getPrayerTimes();
      setState(() {
        _prayerTimes = prayerTimes;
        _isLoading = false;
      });
      _updateNextPrayer();
      _startNextPrayerTimer();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('حدث خطأ: ${e.toString()}')),
        );
      }
    }
  }

  void _updateNextPrayer() {
    if (_prayerTimes == null) return;

    final now = DateTime.now();
    final prayers = {
      'الفجر': _prayerTimes!.fajr,
      'الشروق': _prayerTimes!.sunrise,
      'الظهر': _prayerTimes!.dhuhr,
      'العصر': _prayerTimes!.asr,
      'المغرب': _prayerTimes!.maghrib,
      'العشاء': _prayerTimes!.isha,
    };

    String nextPrayer = '';
    DateTime? nextPrayerTime;

    for (var prayer in prayers.entries) {
      if (prayer.value.isAfter(now)) {
        nextPrayer = prayer.key;
        nextPrayerTime = prayer.value;
        break;
      }
    }

    if (nextPrayer.isEmpty) {
      // If no next prayer found today, get first prayer of tomorrow
      nextPrayer = 'الفجر';
      nextPrayerTime = _prayerTimes!.fajr.add(const Duration(days: 1));
    }

    setState(() {
      _nextPrayer = nextPrayer;
      _timeUntilNextPrayer = nextPrayerTime?.difference(now) ?? Duration.zero;
    });
  }

  void _startNextPrayerTimer() {
    Future.delayed(const Duration(minutes: 1), () {
      if (mounted) {
        _updateNextPrayer();
        _startNextPrayerTimer();
      }
    });
  }

  Widget _buildPrayerTimeCard(String prayerName, DateTime? time) {
    final formattedTime = PrayerService.instance.formatPrayerTime(time);
    final isNext = prayerName == _nextPrayer;

    return Card(
      elevation: isNext ? 8 : 2,
      color: isNext ? Colors.teal.shade50 : null,
      child: ListTile(
        leading: Icon(
          Icons.access_time,
          color: isNext ? Colors.teal : Colors.grey,
        ),
        title: Text(
          prayerName,
          style: TextStyle(
            fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        trailing: Text(
          formattedTime,
          style: TextStyle(
            fontSize: 18,
            fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
            color: isNext ? Colors.teal : null,
          ),
        ),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    return '$hours ساعة و $minutes دقيقة';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مواقيت الصلاة'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadPrayerTimes,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Card(
                    color: Colors.teal.shade100,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Text(
                            _hijriDate,
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'الصلاة القادمة: $_nextPrayer',
                            style: const TextStyle(fontSize: 18),
                          ),
                          Text(
                            'متبقي: ${_formatDuration(_timeUntilNextPrayer)}',
                            style: const TextStyle(fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (_prayerTimes != null) ...[
                    _buildPrayerTimeCard('الفجر', _prayerTimes!.fajr),
                    _buildPrayerTimeCard('الشروق', _prayerTimes!.sunrise),
                    _buildPrayerTimeCard('الظهر', _prayerTimes!.dhuhr),
                    _buildPrayerTimeCard('العصر', _prayerTimes!.asr),
                    _buildPrayerTimeCard('المغرب', _prayerTimes!.maghrib),
                    _buildPrayerTimeCard('العشاء', _prayerTimes!.isha),
                  ],
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          try {
            await PrayerService.instance.schedulePrayerNotifications();
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تم تفعيل التنبيهات بنجاح')),
              );
            }
          } catch (e) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('حدث خطأ في تفعيل التنبيهات')),
              );
            }
          }
        },
        label: const Text('تفعيل التنبيهات'),
        icon: const Icon(Icons.notifications_active),
        backgroundColor: Colors.teal,
      ),
    );
  }
}
