import 'package:flutter/material.dart';
import '../models/athkar.dart';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';

class AthkarScreen extends StatefulWidget {
  const AthkarScreen({super.key});

  @override
  State<AthkarScreen> createState() => _AthkarScreenState();
}

class _AthkarScreenState extends State<AthkarScreen> {
  List<Athkar> _athkarCategories = [];
  bool _isLoading = true;
  final AudioPlayer _audioPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();
    _loadAthkar();
  }

  Future<void> _loadAthkar() async {
    try {
      final String data =
          await rootBundle.loadString('assets/data/athkar.json');
      final List<dynamic> jsonList = json.decode(data);
      setState(() {
        _athkarCategories =
            jsonList.map((json) => Athkar.fromJson(json)).toList();
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحميل الأذكار')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الأذكار'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _athkarCategories.length,
              itemBuilder: (context, index) {
                final category = _athkarCategories[index];
                return Card(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  child: ListTile(
                    title: Text(
                      category.category,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    trailing: Text(
                      '${category.athkar.length} ذكر',
                      style: TextStyle(
                        color: Colors.grey[600],
                      ),
                    ),
                    onTap: () => _showAthkarDetails(category),
                  ),
                );
              },
            ),
    );
  }

  void _showAthkarDetails(Athkar category) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AthkarDetailsScreen(
          category: category,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}

class AthkarDetailsScreen extends StatefulWidget {
  final Athkar category;

  const AthkarDetailsScreen({
    super.key,
    required this.category,
  });

  @override
  State<AthkarDetailsScreen> createState() => _AthkarDetailsScreenState();
}

class _AthkarDetailsScreenState extends State<AthkarDetailsScreen> {
  final PageController _pageController = PageController();
  final AudioPlayer _audioPlayer = AudioPlayer();
  int _currentPage = 0;
  final Map<int, int> _remainingCounts = {};

  @override
  void initState() {
    super.initState();
    _initializeCounts();
  }

  void _initializeCounts() {
    for (var i = 0; i < widget.category.athkar.length; i++) {
      _remainingCounts[i] = widget.category.athkar[i].count;
    }
  }

  void _decrementCount() {
    if (_remainingCounts[_currentPage]! > 0) {
      setState(() {
        _remainingCounts[_currentPage] = _remainingCounts[_currentPage]! - 1;
      });

      if (_remainingCounts[_currentPage] == 0) {
        _showCompletionDialog();
      }
    }
  }

  Future<void> _showCompletionDialog() async {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('أحسنت!'),
        content: const Text('لقد أكملت هذا الذكر'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              if (_currentPage < widget.category.athkar.length - 1) {
                _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              }
            },
            child: const Text('التالي'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.category.category),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              itemCount: widget.category.athkar.length,
              onPageChanged: (index) {
                setState(() {
                  _currentPage = index;
                });
              },
              itemBuilder: (context, index) {
                final thikr = widget.category.athkar[index];
                return SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Card(
                        elevation: 4,
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            children: [
                              Text(
                                thikr.text,
                                style: const TextStyle(
                                  fontSize: 24,
                                  height: 1.5,
                                ),
                                textAlign: TextAlign.center,
                                textDirection: TextDirection.rtl,
                              ),
                              if (thikr.description.isNotEmpty) ...[
                                const Divider(),
                                Text(
                                  thikr.description,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    color: Colors.grey,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      if (thikr.fadl != null) ...[
                        ExpansionTile(
                          title: const Text('الفضل'),
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(16),
                              child: Text(
                                thikr.fadl!,
                                style: const TextStyle(fontSize: 16),
                                textAlign: TextAlign.right,
                              ),
                            ),
                          ],
                        ),
                      ],
                      const SizedBox(height: 16),
                      Text(
                        'المتبقي: ${_remainingCounts[index]}/${thikr.count}',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back_ios),
                  onPressed: _currentPage > 0
                      ? () {
                          _pageController.previousPage(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                          );
                        }
                      : null,
                ),
                ElevatedButton(
                  onPressed: _remainingCounts[_currentPage]! > 0
                      ? _decrementCount
                      : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 16,
                    ),
                  ),
                  child: const Text('تسبيح'),
                ),
                IconButton(
                  icon: const Icon(Icons.arrow_forward_ios),
                  onPressed: _currentPage < widget.category.athkar.length - 1
                      ? () {
                          _pageController.nextPage(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                          );
                        }
                      : null,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }
}
