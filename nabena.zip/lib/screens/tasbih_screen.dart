import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/settings_service.dart';

class TasbihScreen extends StatefulWidget {
  const TasbihScreen({super.key});

  @override
  State<TasbihScreen> createState() => _TasbihScreenState();
}

class _TasbihScreenState extends State<TasbihScreen> {
  final SettingsService _settingsService = SettingsService.instance;
  int _counter = 0;
  bool _vibrateEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _settingsService.loadSettings();
    setState(() {
      _counter = settings.tasbihCounter ?? 0;
      _vibrateEnabled = settings.vibrateEnabled ?? true;
    });
  }

  Future<void> _incrementCounter() async {
    setState(() {
      _counter++;
    });
    await _settingsService.updateSetting('tasbih_counter', _counter);
    if (_vibrateEnabled) {
      HapticFeedback.lightImpact();
    }
  }

  Future<void> _resetCounter() async {
    setState(() {
      _counter = 0;
    });
    await _settingsService.updateSetting('tasbih_counter', _counter);
  }

  Future<void> _toggleVibration() async {
    setState(() {
      _vibrateEnabled = !_vibrateEnabled;
    });
    await _settingsService.updateSetting('vibrate_enabled', _vibrateEnabled);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المسبحة الإلكترونية'),
        centerTitle: true,
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: Icon(
                _vibrateEnabled ? Icons.vibration : Icons.do_not_disturb_on),
            onPressed: _toggleVibration,
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'عدد التسبيحات',
              style: TextStyle(fontSize: 24),
            ),
            Text(
              '$_counter',
              style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _incrementCounter,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
              ),
              child: const Text('سبح', style: TextStyle(fontSize: 24)),
            ),
            const SizedBox(height: 20),
            TextButton(
              onPressed: _resetCounter,
              child:
                  const Text('إعادة التعيين', style: TextStyle(fontSize: 18)),
            ),
          ],
        ),
      ),
    );
  }
}
