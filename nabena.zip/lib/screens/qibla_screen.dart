import 'dart:math' show pi;
import 'package:flutter/material.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:flutter_qiblah/flutter_qiblah.dart';
import '../services/prayer_service.dart';

class QiblaScreen extends StatefulWidget {
  const QiblaScreen({super.key});

  @override
  State<QiblaScreen> createState() => _QiblaScreenState();
}

class _QiblaScreenState extends State<QiblaScreen> {
  String _qiblaDirection = '';
  double _compassDirection = 0;
  bool _hasPermission = false;

  @override
  void initState() {
    super.initState();
    _checkPermissions();
    _loadQiblaDirection();
    _startCompassListener();
  }

  Future<void> _checkPermissions() async {
    final hasPermission = await FlutterQiblah.checkLocationPermission();
    setState(() {
      _hasPermission = hasPermission;
    });
  }

  Future<void> _loadQiblaDirection() async {
    try {
      final direction = await PrayerService.instance.getQiblaDirection();
      setState(() {
        _qiblaDirection = direction;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحديد اتجاه القبلة')),
        );
      }
    }
  }

  void _startCompassListener() {
    FlutterCompass.events?.listen((event) {
      setState(() {
        _compassDirection = event.heading ?? 0;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_hasPermission) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('اتجاه القبلة'),
          centerTitle: true,
          backgroundColor: Colors.teal,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('يرجى السماح بالوصول إلى موقعك لتحديد اتجاه القبلة'),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _checkPermissions,
                child: const Text('السماح بالوصول'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('اتجاه القبلة'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Text(
            'اتجاه القبلة: $_qiblaDirection',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: Center(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 300,
                    height: 300,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.teal, width: 2),
                    ),
                  ),
                  Transform.rotate(
                    angle: (_compassDirection * (pi / 180) * -1),
                    child: Image.asset(
                      'assets/icons/compass.png',
                      width: 280,
                      height: 280,
                    ),
                  ),
                  Transform.rotate(
                    angle:
                        (double.tryParse(_qiblaDirection.replaceAll('°', '')) ??
                                0) *
                            (pi / 180),
                    child: const Icon(
                      Icons.arrow_upward,
                      color: Colors.teal,
                      size: 50,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              'قم بتوجيه الجهاز بشكل أفقي وتحريكه حتى يشير السهم إلى اتجاه القبلة',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    FlutterCompass.events?.drain();
    super.dispose();
  }
}
