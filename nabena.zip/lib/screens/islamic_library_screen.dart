import 'package:flutter/material.dart';
import '../models/book.dart';
import '../services/settings_service.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:shared_preferences.dart';

class IslamicLibraryScreen extends StatefulWidget {
  const IslamicLibraryScreen({super.key});

  @override
  State<IslamicLibraryScreen> createState() => _IslamicLibraryScreenState();
}

class _IslamicLibraryScreenState extends State<IslamicLibraryScreen> {
  final SettingsService _settingsService = SettingsService.instance;
  List<Book> _books = [];
  List<Book> _filteredBooks = [];
  bool _isLoading = true;
  String _selectedCategory = 'الكل';
  final TextEditingController _searchController = TextEditingController();
  double _fontSize = 18.0;

  final List<String> _categories = [
    'الكل',
    'التفسير',
    'الحديث',
    'الفقه',
    'العقيدة',
    'السيرة',
    'الأخلاق',
    'الأذكار',
    'الرقائق',
  ];

  @override
  void initState() {
    super.initState();
    _loadBooks();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _settingsService.loadSettings();
    setState(() {
      _fontSize = settings.fontSize;
    });
  }

  Future<void> _loadBooks() async {
    try {
      // In a real app, this would load from assets or an API
      final List<Book> books = [
        Book(
          id: '1',
          title: 'رياض الصالحين',
          author: 'الإمام النووي',
          category: 'الحديث',
          description: 'كتاب جامع للأحاديث النبوية في الأخلاق والآداب',
          filePath: 'assets/books/riyad_assaliheen.md',
          totalPages: 300,
          tags: ['حديث', 'أخلاق', 'آداب'],
        ),
        // Add more books here
      ];

      setState(() {
        _books = books;
        _filteredBooks = books;
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحميل المكتبة')),
        );
      }
    }
  }

  void _filterBooks(String query) {
    setState(() {
      if (_selectedCategory == 'الكل') {
        _filteredBooks = _books.where((book) {
          return book.title.contains(query) ||
              book.author.contains(query) ||
              book.description.contains(query);
        }).toList();
      } else {
        _filteredBooks = _books.where((book) {
          return (book.title.contains(query) ||
                  book.author.contains(query) ||
                  book.description.contains(query)) &&
              book.category == _selectedCategory;
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المكتبة الإسلامية'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    controller: _searchController,
                    decoration: const InputDecoration(
                      hintText: 'ابحث عن كتاب...',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: _filterBooks,
                  ),
                ),
                SizedBox(
                  height: 50,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _categories.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(
                          label: Text(_categories[index]),
                          selected: _selectedCategory == _categories[index],
                          onSelected: (selected) {
                            setState(() {
                              _selectedCategory = _categories[index];
                              _filterBooks(_searchController.text);
                            });
                          },
                        ),
                      );
                    },
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: _filteredBooks.length,
                    itemBuilder: (context, index) {
                      final book = _filteredBooks[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        child: ListTile(
                          leading: const Icon(Icons.book),
                          title: Text(
                            book.title,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            '${book.author} - ${book.category}',
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.arrow_forward_ios),
                            onPressed: () => _openBook(book),
                          ),
                          onTap: () => _showBookDetails(book),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }

  void _showBookDetails(Book book) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              book.title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text('المؤلف: ${book.author}'),
            const SizedBox(height: 8),
            Text(book.description),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: book.tags
                  .map((tag) => Chip(
                        label: Text(tag),
                        backgroundColor: Colors.teal.shade50,
                      ))
                  .toList(),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  icon: const Icon(Icons.book),
                  label: const Text('قراءة'),
                  onPressed: () {
                    Navigator.pop(context);
                    _openBook(book);
                  },
                ),
                ElevatedButton.icon(
                  icon: const Icon(Icons.download),
                  label: const Text('تحميل'),
                  onPressed: () {
                    // Implement download functionality
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _openBook(Book book) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BookReaderScreen(
          book: book,
          fontSize: _fontSize,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}

class BookReaderScreen extends StatefulWidget {
  final Book book;
  final double fontSize;

  const BookReaderScreen({
    super.key,
    required this.book,
    required this.fontSize,
  });

  @override
  State<BookReaderScreen> createState() => _BookReaderScreenState();
}

class _BookReaderScreenState extends State<BookReaderScreen> {
  String _content = '';
  bool _isLoading = true;
  final ScrollController _scrollController = ScrollController();
  double _fontSize;

  _BookReaderScreenState() : _fontSize = 18.0;

  @override
  void initState() {
    super.initState();
    _fontSize = widget.fontSize;
    _loadBookContent();
    _loadLastPosition();
  }

  Future<void> _loadBookContent() async {
    try {
      final String content =
          await DefaultAssetBundle.of(context).loadString(widget.book.filePath);
      setState(() {
        _content = content;
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحميل الكتاب')),
        );
      }
    }
  }

  Future<void> _loadLastPosition() async {
    final prefs = await SharedPreferences.getInstance();
    final double? position = prefs.getDouble('book_${widget.book.id}_position');
    if (position != null && _scrollController.hasClients) {
      _scrollController.jumpTo(position);
    }
  }

  Future<void> _savePosition() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(
      'book_${widget.book.id}_position',
      _scrollController.position.pixels,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.book.title),
        centerTitle: true,
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: const Icon(Icons.text_decrease),
            onPressed: () {
              setState(() {
                if (_fontSize > 14) {
                  _fontSize -= 2;
                }
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.text_increase),
            onPressed: () {
              setState(() {
                if (_fontSize < 30) {
                  _fontSize += 2;
                }
              });
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Markdown(
              controller: _scrollController,
              data: _content,
              styleSheet: MarkdownStyleSheet(
                p: TextStyle(
                  fontSize: _fontSize,
                  height: 1.5,
                ),
                h1: TextStyle(
                  fontSize: _fontSize + 8,
                  fontWeight: FontWeight.bold,
                ),
                h2: TextStyle(
                  fontSize: _fontSize + 6,
                  fontWeight: FontWeight.bold,
                ),
                h3: TextStyle(
                  fontSize: _fontSize + 4,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
    );
  }

  @override
  void dispose() {
    _savePosition();
    _scrollController.dispose();
    super.dispose();
  }
}
