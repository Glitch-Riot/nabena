import 'package:flutter/material.dart';
import '../services/memorization_service.dart';
import '../models/surah.dart';
import '../services/quran_service.dart';
import 'dart:async';

class MemorizationTestScreen extends StatefulWidget {
  final int surahNumber;
  final List<int> verseNumbers;

  const MemorizationTestScreen({
    super.key,
    required this.surahNumber,
    required this.verseNumbers,
  });

  @override
  State<MemorizationTestScreen> createState() => _MemorizationTestScreenState();
}

class _MemorizationTestScreenState extends State<MemorizationTestScreen> {
  final MemorizationService _memorizationService = MemorizationService.instance;
  final QuranService _quranService = QuranService.instance;
  late Surah _surah;
  List<String> _verses = [];
  int _currentQuestionIndex = 0;
  int _score = 0;
  bool _isLoading = true;
  late Timer _timer;
  int _secondsElapsed = 0;
  final TextEditingController _answerController = TextEditingController();
  bool _showAnswer = false;

  @override
  void initState() {
    super.initState();
    _loadSurahData();
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _secondsElapsed++;
      });
    });
  }

  Future<void> _loadSurahData() async {
    try {
      // Load surah content
      final String content =
          await _quranService.loadSurahContent(widget.surahNumber);
      final List<String> allVerses = content.split('\n');

      // Filter verses for the test
      _verses =
          widget.verseNumbers.map((index) => allVerses[index - 1]).toList();
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحميل السورة')),
        );
      }
    }
  }

  void _checkAnswer() {
    final bool isCorrect =
        _answerController.text.trim() == _verses[_currentQuestionIndex];
    if (isCorrect) {
      setState(() {
        _score++;
      });
    }
    setState(() {
      _showAnswer = true;
    });
  }

  void _nextQuestion() {
    if (_currentQuestionIndex < _verses.length - 1) {
      setState(() {
        _currentQuestionIndex++;
        _showAnswer = false;
        _answerController.clear();
      });
    } else {
      _finishTest();
    }
  }

  Future<void> _finishTest() async {
    _timer.cancel();
    final test = _memorizationService.createTest(
      userId:
          'current_user_id', // Replace with actual user ID when implementing authentication
      surahNumber: widget.surahNumber,
      verseNumbers: widget.verseNumbers,
      score: _score,
      timeSpent: Duration(seconds: _secondsElapsed),
    );

    await _memorizationService.saveTest(test);

    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => TestResultScreen(
            test: test,
            totalVerses: _verses.length,
          ),
        ),
      );
    }
  }

  String _formatDuration(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('اختبار الحفظ'),
        centerTitle: true,
        backgroundColor: Colors.teal,
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                _formatDuration(_secondsElapsed),
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  LinearProgressIndicator(
                    value: (_currentQuestionIndex + 1) / _verses.length,
                    backgroundColor: Colors.grey[200],
                    color: Colors.teal,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'السؤال ${_currentQuestionIndex + 1} من ${_verses.length}',
                    style: const TextStyle(fontSize: 18),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'أكمل الآية:',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: TextField(
                        controller: _answerController,
                        maxLines: 3,
                        textAlign: TextAlign.right,
                        decoration: const InputDecoration(
                          hintText: 'اكتب الآية هنا...',
                          border: OutlineInputBorder(),
                        ),
                        enabled: !_showAnswer,
                      ),
                    ),
                  ),
                  if (_showAnswer) ...[
                    const SizedBox(height: 16),
                    Card(
                      color: Colors.teal.shade50,
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            const Text(
                              'الإجابة الصحيحة:',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _verses[_currentQuestionIndex],
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 18,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                  const Spacer(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      if (!_showAnswer)
                        ElevatedButton(
                          onPressed: _checkAnswer,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 32,
                              vertical: 16,
                            ),
                          ),
                          child: const Text('تحقق من الإجابة'),
                        )
                      else
                        ElevatedButton(
                          onPressed: _nextQuestion,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 32,
                              vertical: 16,
                            ),
                          ),
                          child: Text(
                            _currentQuestionIndex < _verses.length - 1
                                ? 'السؤال التالي'
                                : 'إنهاء الاختبار',
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    _answerController.dispose();
    super.dispose();
  }
}
