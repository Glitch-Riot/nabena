import 'package:flutter/material.dart';
import '../models/duaa.dart';
import 'package:shared_preferences.dart';
import 'dart:convert';
import 'package:uuid/uuid.dart';

class DuaaScreen extends StatefulWidget {
  const DuaaScreen({super.key});

  @override
  State<DuaaScreen> createState() => _DuaaScreenState();
}

class _DuaaScreenState extends State<DuaaScreen> {
  final List<String> _categories = [
    'الصحة',
    'الرزق',
    'الذرية',
    'التوفيق',
    'المغفرة',
    'الهداية',
    'العلم',
    'أخرى',
  ];

  final TextEditingController _duaaController = TextEditingController();
  List<String> _selectedCategories = [];
  bool _isAnonymous = false;
  List<Duaa> _duaas = [];
  bool _isLoading = true;
  final _uuid = const Uuid();

  @override
  void initState() {
    super.initState();
    _loadDuaas();
  }

  Future<void> _loadDuaas() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? duaasJson = prefs.getString('duaas');
      if (duaasJson != null) {
        final List<dynamic> duaasList = json.decode(duaasJson);
        setState(() {
          _duaas = duaasList
              .map((json) => Duaa.fromJson(json as Map<String, dynamic>))
              .toList();
          _isLoading = false;
        });
      } else {
        setState(() {
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحميل الدعوات')),
        );
      }
    }
  }

  Future<void> _saveDuaas() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String duaasJson =
          json.encode(_duaas.map((d) => d.toJson()).toList());
      await prefs.setString('duaas', duaasJson);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في حفظ الدعوات')),
        );
      }
    }
  }

  Future<void> _addDuaa() async {
    if (_duaaController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('الرجاء كتابة الدعاء')),
      );
      return;
    }

    if (_selectedCategories.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('الرجاء اختيار فئة واحدة على الأقل')),
      );
      return;
    }

    final newDuaa = Duaa(
      id: _uuid.v4(),
      userId:
          'current_user_id', // Replace with actual user ID when implementing authentication
      content: _duaaController.text.trim(),
      createdAt: DateTime.now(),
      categories: _selectedCategories,
      isAnonymous: _isAnonymous,
    );

    setState(() {
      _duaas.add(newDuaa);
      _duaaController.clear();
      _selectedCategories = [];
      _isAnonymous = false;
    });

    await _saveDuaas();
  }

  Future<void> _incrementPrayCount(String duaaId) async {
    setState(() {
      final index = _duaas.indexWhere((d) => d.id == duaaId);
      if (index != -1) {
        final updatedDuaa = _duaas[index].copyWith(
          prayCount: _duaas[index].prayCount + 1,
        );
        _duaas[index] = updatedDuaa;
      }
    });
    await _saveDuaas();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('دعوة غريب'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(
                        controller: _duaaController,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          hintText: 'اكتب دعاءك هنا...',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: _categories.map((category) {
                          final isSelected =
                              _selectedCategories.contains(category);
                          return FilterChip(
                            label: Text(category),
                            selected: isSelected,
                            onSelected: (selected) {
                              setState(() {
                                if (selected) {
                                  _selectedCategories.add(category);
                                } else {
                                  _selectedCategories.remove(category);
                                }
                              });
                            },
                          );
                        }).toList(),
                      ),
                      Row(
                        children: [
                          Checkbox(
                            value: _isAnonymous,
                            onChanged: (value) {
                              setState(() {
                                _isAnonymous = value ?? false;
                              });
                            },
                          ),
                          const Text('نشر بدون اسم'),
                          const Spacer(),
                          ElevatedButton(
                            onPressed: _addDuaa,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.teal,
                            ),
                            child: const Text('نشر الدعاء'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Expanded(
                  child: ListView.builder(
                    itemCount: _duaas.length,
                    itemBuilder: (context, index) {
                      final duaa = _duaas[_duaas.length - 1 - index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                duaa.content,
                                style: const TextStyle(
                                  fontSize: 16,
                                  height: 1.5,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  Text(
                                    duaa.isAnonymous ? 'مجهول' : 'مسلم',
                                    style: TextStyle(
                                      color: Colors.grey[600],
                                      fontSize: 12,
                                    ),
                                  ),
                                  const Spacer(),
                                  TextButton.icon(
                                    icon: const Icon(Icons.favorite),
                                    label: Text('${duaa.prayCount}'),
                                    onPressed: () =>
                                        _incrementPrayCount(duaa.id),
                                  ),
                                ],
                              ),
                              Wrap(
                                spacing: 8,
                                children: duaa.categories
                                    .map((category) => Chip(
                                          label: Text(category),
                                          backgroundColor: Colors.teal.shade50,
                                        ))
                                    .toList(),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }

  @override
  void dispose() {
    _duaaController.dispose();
    super.dispose();
  }
}
