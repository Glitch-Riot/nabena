import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  static const List<Map<String, dynamic>> features = [
    {'title': 'القرآن الكريم', 'icon': Icons.menu_book, 'route': '/quran'},
    {'title': 'الأذكار', 'icon': Icons.mosque, 'route': '/athkar'},
    {'title': 'المسبحة الإلكترونية', 'icon': Icons.touch_app, 'route': '/tasbih'},
    {'title': 'مواقيت الصلاة', 'icon': Icons.access_time, 'route': '/prayer_times'},
    {'title': 'اتجاه القبلة', 'icon': Icons.explore, 'route': '/qibla'},
    {'title': 'المكتبة الإسلامية', 'icon': Icons.library_books, 'route': '/library'},
    {'title': 'ختمة القرآن', 'icon': Icons.book, 'route': '/khatmah'},
    {'title': 'تفسير الأحلام', 'icon': Icons.nightlight, 'route': '/dreams'},
    {'title': 'حاسبة الزكاة', 'icon': Icons.calculate, 'route': '/zakat'},
    {'title': 'الأحاديث النبوية', 'icon': Icons.history_edu, 'route': '/hadith'},
    {'title': 'دعوة غريب', 'icon': Icons.favorite, 'route': '/duaa'},
    {'title': 'اختبر حفظك', 'icon': Icons.quiz, 'route': '/memorization_test'},
    {'title': 'التحفيظ بالتكرار', 'icon': Icons.repeat, 'route': '/memorization'},
    {'title': 'التقويم الهجري', 'icon': Icons.calendar_today, 'route': '/hijri_calendar'},
    {'title': 'أسماء الله الحسنى', 'icon': Icons.star, 'route': '/allah_names'},
  ];

  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          children: [
            Text('أنيس المسلم'),
            Text(
              'تطبيق إسلامي شامل',
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            color: Colors.teal.shade50,
            child: const Text(
              'تطبيق شامل يعمل بدون إنترنت',
              style: TextStyle(
                fontSize: 16,
                color: Colors.teal,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1.2,
              ),
              itemCount: features.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(context, features[index]['route']);
                  },
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    elevation: 4,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(features[index]['icon'], size: 40, color: Colors.teal),
                        const SizedBox(height: 8),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: Text(
                            features[index]['title'],
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
