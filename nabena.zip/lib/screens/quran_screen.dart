import 'package:flutter/material.dart';
import '../services/quran_service.dart';
import '../models/surah.dart';
import '../services/settings_service.dart';

class QuranScreen extends StatefulWidget {
  const QuranScreen({super.key});

  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> {
  final QuranService _quranService = QuranService.instance;
  final SettingsService _settingsService = SettingsService.instance;
  List<Surah> _surahs = [];
  bool _isLoading = true;
  String _selectedReciter = 'عبد الباسط عبد الصمد';
  double _fontSize = 18.0;

  @override
  void initState() {
    super.initState();
    _loadSurahs();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _settingsService.loadSettings();
    setState(() {
      _selectedReciter = settings.quranReciter;
      _fontSize = settings.fontSize;
    });
  }

  Future<void> _loadSurahs() async {
    try {
      final surahs = await _quranService.loadSurahs();
      setState(() {
        _surahs = surahs;
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحميل القرآن الكريم')),
        );
      }
    }
  }

  void _showSurahContent(Surah surah) async {
    try {
      final content = await _quranService.loadSurahContent(surah.number);
      if (!mounted) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SurahContentScreen(
            surah: surah,
            content: content,
            reciter: _selectedReciter,
            fontSize: _fontSize,
          ),
        ),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحميل السورة')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('القرآن الكريم'),
        centerTitle: true,
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _showSettings,
          ),
          IconButton(
            icon: const Icon(Icons.bookmark),
            onPressed: _showBookmarks,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _surahs.length,
              itemBuilder: (context, index) {
                final surah = _surahs[index];
                return ListTile(
                  leading: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.teal),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                      child: Text(
                        surah.number.toString(),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  title: Text(surah.name),
                  subtitle: Text(
                    '${surah.englishName} - ${surah.numberOfAyahs} آية',
                  ),
                  trailing: Text(
                    surah.revelationType == 'Meccan' ? 'مكية' : 'مدنية',
                    style: TextStyle(
                      color: surah.revelationType == 'Meccan'
                          ? Colors.teal
                          : Colors.blue,
                    ),
                  ),
                  onTap: () => _showSurahContent(surah),
                );
              },
            ),
    );
  }

  void _showSettings() async {
    final settings = await _settingsService.loadSettings();
    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'الإعدادات',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                title: const Text('القارئ'),
                subtitle: Text(_selectedReciter),
                onTap: () {
                  // Show reciter selection dialog
                },
              ),
              ListTile(
                title: const Text('حجم الخط'),
                subtitle: Slider(
                  value: _fontSize,
                  min: 14,
                  max: 30,
                  divisions: 8,
                  label: _fontSize.toString(),
                  onChanged: (value) {
                    setState(() {
                      _fontSize = value;
                    });
                    _settingsService.updateSetting('font_size', value);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showBookmarks() async {
    final settings = await _settingsService.loadSettings();
    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      builder: (context) => ListView.builder(
        itemCount: settings.bookmarks.length,
        itemBuilder: (context, index) {
          final bookmark = settings.bookmarks[index];
          return ListTile(
            title: Text(bookmark),
            trailing: IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () {
                _settingsService.removeBookmark(bookmark);
                Navigator.pop(context);
              },
            ),
            onTap: () {
              // Navigate to bookmarked position
              Navigator.pop(context);
            },
          );
        },
      ),
    );
  }
}

class SurahContentScreen extends StatefulWidget {
  final Surah surah;
  final String content;
  final String reciter;
  final double fontSize;

  const SurahContentScreen({
    super.key,
    required this.surah,
    required this.content,
    required this.reciter,
    required this.fontSize,
  });

  @override
  State<SurahContentScreen> createState() => _SurahContentScreenState();
}

class _SurahContentScreenState extends State<SurahContentScreen> {
  final QuranService _quranService = QuranService.instance;
  bool _isPlaying = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.surah.name),
        centerTitle: true,
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
            onPressed: _toggleAudio,
          ),
          IconButton(
            icon: const Icon(Icons.bookmark_add),
            onPressed: () {
              // Add bookmark functionality
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.teal.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                children: [
                  Text(
                    'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
                    style: TextStyle(
                      fontSize: widget.fontSize + 2,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${widget.surah.englishNameTranslation} - ${widget.surah.numberOfAyahs} Ayahs',
                    style: const TextStyle(
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              widget.content,
              style: TextStyle(
                fontSize: widget.fontSize,
                height: 2,
              ),
              textAlign: TextAlign.right,
              textDirection: TextDirection.rtl,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _toggleAudio() async {
    if (_isPlaying) {
      await _quranService.stopAudio();
    } else {
      await _quranService.playAudio(widget.reciter, widget.surah.number);
    }
    setState(() {
      _isPlaying = !_isPlaying;
    });
  }

  @override
  void dispose() {
    _quranService.stopAudio();
    super.dispose();
  }
}
