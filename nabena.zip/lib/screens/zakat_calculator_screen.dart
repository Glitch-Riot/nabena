import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ZakatCalculatorScreen extends StatefulWidget {
  const ZakatCalculatorScreen({super.key});

  @override
  State<ZakatCalculatorScreen> createState() => _ZakatCalculatorScreenState();
}

class _ZakatCalculatorScreenState extends State<ZakatCalculatorScreen> {
  final _formKey = GlobalKey<FormState>();
  final _currencyFormatter = NumberFormat.currency(
    symbol: '',
    decimalDigits: 2,
  );

  double _cash = 0;
  double _gold = 0;
  double _silver = 0;
  double _stocks = 0;
  double _realEstate = 0;
  double _businessAssets = 0;
  double _debtsOwed = 0;
  double _debtsOwing = 0;

  // النصاب based on current gold price (approximately)
  final double _nisabGold = 85 * 240; // 85 grams * approximate price per gram

  double _calculateTotal() {
    return _cash +
        _gold +
        _silver +
        _stocks +
        _realEstate +
        _businessAssets +
        _debtsOwed -
        _debtsOwing;
  }

  double _calculateZakat() {
    final total = _calculateTotal();
    return total >= _nisabGold ? total * 0.025 : 0;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('حاسبة الزكاة'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      const Text(
                        'نصاب الزكاة',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${_currencyFormatter.format(_nisabGold)} ريال',
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.teal,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              _buildNumberField(
                'النقود السائلة',
                (value) => setState(() => _cash = value),
              ),
              _buildNumberField(
                'الذهب',
                (value) => setState(() => _gold = value),
              ),
              _buildNumberField(
                'الفضة',
                (value) => setState(() => _silver = value),
              ),
              _buildNumberField(
                'الأسهم والاستثمارات',
                (value) => setState(() => _stocks = value),
              ),
              _buildNumberField(
                'العقارات المعدة للبيع',
                (value) => setState(() => _realEstate = value),
              ),
              _buildNumberField(
                'أصول تجارية',
                (value) => setState(() => _businessAssets = value),
              ),
              _buildNumberField(
                'ديون لك على الآخرين',
                (value) => setState(() => _debtsOwed = value),
              ),
              _buildNumberField(
                'ديون عليك للآخرين',
                (value) => setState(() => _debtsOwing = value),
              ),
              const SizedBox(height: 24),
              Card(
                color: Colors.teal.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      const Text(
                        'النتائج',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('إجمالي الأموال:'),
                          Text(
                            '${_currencyFormatter.format(_calculateTotal())} ريال',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      const Divider(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('مقدار الزكاة:'),
                          Text(
                            '${_currencyFormatter.format(_calculateZakat())} ريال',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.teal,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              if (_calculateTotal() < _nisabGold)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                      'لم يبلغ المال النصاب، لا تجب عليك الزكاة',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _cash = 0;
            _gold = 0;
            _silver = 0;
            _stocks = 0;
            _realEstate = 0;
            _businessAssets = 0;
            _debtsOwed = 0;
            _debtsOwing = 0;
          });
          _formKey.currentState?.reset();
        },
        backgroundColor: Colors.teal,
        child: const Icon(Icons.refresh),
      ),
    );
  }

  Widget _buildNumberField(String label, Function(double) onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
          suffixText: 'ريال',
        ),
        onChanged: (value) {
          final number = double.tryParse(value);
          if (number != null) {
            onChanged(number);
          }
        },
        validator: (value) {
          if (value != null && value.isNotEmpty) {
            if (double.tryParse(value) == null) {
              return 'الرجاء إدخال رقم صحيح';
            }
          }
          return null;
        },
      ),
    );
  }
}
