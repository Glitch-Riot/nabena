import 'package:flutter/material.dart';
import '../services/settings_service.dart';
import '../services/notification_service.dart';

class KhatmahScreen extends StatefulWidget {
  const KhatmahScreen({super.key});

  @override
  State<KhatmahScreen> createState() => _KhatmahScreenState();
}

class _KhatmahScreenState extends State<KhatmahScreen> {
  final SettingsService _settingsService = SettingsService.instance;
  int _currentPage = 1;
  int _targetPages = 20;
  bool _notificationsEnabled = true;
  TimeOfDay _reminderTime = const TimeOfDay(hour: 9, minute: 0);

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _settingsService.loadSettings();
    setState(() {
      _currentPage = settings.lastReadPage;
      _targetPages = settings.dailyKhatmahPages ?? 20;
      _notificationsEnabled = settings.notificationsEnabled;
      _reminderTime = TimeOfDay(
        hour: settings.khatmahReminderHour ?? 9,
        minute: settings.khatmahReminderMinute ?? 0,
      );
    });
  }

  Future<void> _saveSettings() async {
    await _settingsService.updateSetting('daily_target_pages', _targetPages);
    await _settingsService.updateSetting('reminder_hour', _reminderTime.hour);
    await _settingsService.updateSetting(
        'reminder_minute', _reminderTime.minute);

    if (_notificationsEnabled) {
      final now = DateTime.now();
      final reminderTime = DateTime(
        now.year,
        now.month,
        now.day,
        _reminderTime.hour,
        _reminderTime.minute,
      );
      await NotificationService.instance.scheduleQuranKhatmahReminder(
        'تذكير بقراءة القرآن',
        'هل قرأت وردك اليوم؟ الهدف: $_targetPages صفحة',
        reminderTime,
      );
    }
  }

  void _showReminderTimePicker() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _reminderTime,
    );
    if (picked != null) {
      setState(() {
        _reminderTime = picked;
      });
      _saveSettings();
    }
  }

  @override
  Widget build(BuildContext context) {
    final double progress =
        (_currentPage / 604) * 100; // 604 is total Quran pages
    final remainingPages = 604 - _currentPage;
    final estimatedDays = (remainingPages / _targetPages).ceil();

    return Scaffold(
      appBar: AppBar(
        title: const Text('ختمة القرآن'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text(
                      'تقدم الختمة',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    CircularProgressIndicator(
                      value: progress / 100,
                      backgroundColor: Colors.grey[200],
                      color: Colors.teal,
                      strokeWidth: 10,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '${progress.toStringAsFixed(1)}%',
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal,
                      ),
                    ),
                    Text(
                      'الصفحة $_currentPage من 604',
                      style: const TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'الورد اليومي',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const Text('عدد الصفحات:'),
                        Expanded(
                          child: Slider(
                            value: _targetPages.toDouble(),
                            min: 1,
                            max: 50,
                            divisions: 49,
                            label: _targetPages.toString(),
                            onChanged: (value) {
                              setState(() {
                                _targetPages = value.round();
                              });
                              _saveSettings();
                            },
                          ),
                        ),
                        Text(_targetPages.toString()),
                      ],
                    ),
                    const Divider(),
                    ListTile(
                      title: const Text('وقت التذكير'),
                      subtitle: Text(
                        _reminderTime.format(context),
                      ),
                      trailing: Switch(
                        value: _notificationsEnabled,
                        onChanged: (value) {
                          setState(() {
                            _notificationsEnabled = value;
                          });
                          _settingsService.updateSetting(
                              'notifications_enabled', value);
                          _saveSettings();
                        },
                      ),
                      onTap: _showReminderTimePicker,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text(
                      'تحديث التقدم',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.remove),
                          onPressed: _currentPage > 1
                              ? () {
                                  setState(() {
                                    _currentPage--;
                                  });
                                  _settingsService.updateSetting(
                                    'last_read_page',
                                    _currentPage,
                                  );
                                }
                              : null,
                        ),
                        const SizedBox(width: 16),
                        Text(
                          _currentPage.toString(),
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(width: 16),
                        IconButton(
                          icon: const Icon(Icons.add),
                          onPressed: _currentPage < 604
                              ? () {
                                  setState(() {
                                    _currentPage++;
                                  });
                                  _settingsService.updateSetting(
                                    'last_read_page',
                                    _currentPage,
                                  );
                                }
                              : null,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              color: Colors.teal.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text(
                      'التوقع',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'بمعدل $_targetPages صفحة يومياً',
                      style: const TextStyle(color: Colors.grey),
                    ),
                    Text(
                      'ستختم القرآن خلال $estimatedDays يوم',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
