import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart';

class Hadith {
  final String text;
  final String narrator;
  final String source;
  final String grade;
  final String? explanation;
  final List<String> categories;

  Hadith({
    required this.text,
    required this.narrator,
    required this.source,
    required this.grade,
    this.explanation,
    required this.categories,
  });

  factory Hadith.fromJson(Map<String, dynamic> json) {
    return Hadith(
      text: json['text'],
      narrator: json['narrator'],
      source: json['source'],
      grade: json['grade'],
      explanation: json['explanation'],
      categories: List<String>.from(json['categories']),
    );
  }
}

class HadithScreen extends StatefulWidget {
  const HadithScreen({super.key});

  @override
  State<HadithScreen> createState() => _HadithScreenState();
}

class _HadithScreenState extends State<HadithScreen> {
  List<Hadith> _hadiths = [];
  List<Hadith> _filteredHadiths = [];
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();
  String _selectedCategory = 'الكل';
  List<String> _categories = ['الكل'];

  @override
  void initState() {
    super.initState();
    _loadHadiths();
  }

  Future<void> _loadHadiths() async {
    try {
      final String data =
          await rootBundle.loadString('assets/data/hadiths.json');
      final List<dynamic> jsonList = json.decode(data);
      final hadiths = jsonList.map((json) => Hadith.fromJson(json)).toList();

      // Extract unique categories
      final Set<String> categorySet = {'الكل'};
      for (var hadith in hadiths) {
        categorySet.addAll(hadith.categories);
      }

      setState(() {
        _hadiths = hadiths;
        _filteredHadiths = hadiths;
        _categories = categorySet.toList()..sort();
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحميل الأحاديث')),
        );
      }
    }
  }

  void _filterHadiths(String query) {
    setState(() {
      if (_selectedCategory == 'الكل') {
        _filteredHadiths = _hadiths.where((hadith) {
          return hadith.text.contains(query) ||
              hadith.narrator.contains(query) ||
              hadith.source.contains(query);
        }).toList();
      } else {
        _filteredHadiths = _hadiths.where((hadith) {
          return (hadith.text.contains(query) ||
                  hadith.narrator.contains(query) ||
                  hadith.source.contains(query)) &&
              hadith.categories.contains(_selectedCategory);
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الأحاديث النبوية'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    controller: _searchController,
                    decoration: const InputDecoration(
                      hintText: 'ابحث في الأحاديث...',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: _filterHadiths,
                  ),
                ),
                SizedBox(
                  height: 50,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _categories.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(
                          label: Text(_categories[index]),
                          selected: _selectedCategory == _categories[index],
                          onSelected: (selected) {
                            setState(() {
                              _selectedCategory = _categories[index];
                              _filterHadiths(_searchController.text);
                            });
                          },
                        ),
                      );
                    },
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: _filteredHadiths.length,
                    itemBuilder: (context, index) {
                      final hadith = _filteredHadiths[index];
                      return Card(
                        margin: const EdgeInsets.all(8),
                        child: ExpansionTile(
                          title: Text(
                            hadith.text,
                            style: const TextStyle(
                              fontSize: 16,
                              height: 1.5,
                            ),
                            textDirection: TextDirection.rtl,
                          ),
                          subtitle: Text(
                            hadith.narrator,
                            style: const TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('المصدر: ${hadith.source}'),
                                  Text('الدرجة: ${hadith.grade}'),
                                  if (hadith.explanation != null) ...[
                                    const Divider(),
                                    const Text(
                                      'الشرح:',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(hadith.explanation!),
                                  ],
                                  const Divider(),
                                  Wrap(
                                    spacing: 8,
                                    children: hadith.categories
                                        .map((category) => Chip(
                                              label: Text(category),
                                              backgroundColor:
                                                  Colors.teal.shade50,
                                            ))
                                        .toList(),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
