import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart';

class DreamSymbol {
  final String symbol;
  final String interpretation;
  final List<String> categories;
  final List<String> relatedSymbols;

  DreamSymbol({
    required this.symbol,
    required this.interpretation,
    required this.categories,
    required this.relatedSymbols,
  });

  factory DreamSymbol.fromJson(Map<String, dynamic> json) {
    return DreamSymbol(
      symbol: json['symbol'],
      interpretation: json['interpretation'],
      categories: List<String>.from(json['categories']),
      relatedSymbols: List<String>.from(json['relatedSymbols']),
    );
  }
}

class DreamsScreen extends StatefulWidget {
  const DreamsScreen({super.key});

  @override
  State<DreamsScreen> createState() => _DreamsScreenState();
}

class _DreamsScreenState extends State<DreamsScreen> {
  List<DreamSymbol> _symbols = [];
  List<DreamSymbol> _filteredSymbols = [];
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();
  String _selectedCategory = 'الكل';
  List<String> _categories = ['الكل'];

  @override
  void initState() {
    super.initState();
    _loadDreamSymbols();
  }

  Future<void> _loadDreamSymbols() async {
    try {
      final String data =
          await rootBundle.loadString('assets/data/dreams.json');
      final List<dynamic> jsonList = json.decode(data);
      final symbols =
          jsonList.map((json) => DreamSymbol.fromJson(json)).toList();

      final Set<String> categorySet = {'الكل'};
      for (var symbol in symbols) {
        categorySet.addAll(symbol.categories);
      }

      setState(() {
        _symbols = symbols;
        _filteredSymbols = symbols;
        _categories = categorySet.toList()..sort();
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حدث خطأ في تحميل قاموس تفسير الأحلام')),
        );
      }
    }
  }

  void _filterSymbols(String query) {
    setState(() {
      if (_selectedCategory == 'الكل') {
        _filteredSymbols = _symbols.where((symbol) {
          return symbol.symbol.contains(query) ||
              symbol.interpretation.contains(query);
        }).toList();
      } else {
        _filteredSymbols = _symbols.where((symbol) {
          return (symbol.symbol.contains(query) ||
                  symbol.interpretation.contains(query)) &&
              symbol.categories.contains(_selectedCategory);
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تفسير الأحلام'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    controller: _searchController,
                    decoration: const InputDecoration(
                      hintText: 'ابحث عن رمز أو معنى...',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: _filterSymbols,
                  ),
                ),
                SizedBox(
                  height: 50,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _categories.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(
                          label: Text(_categories[index]),
                          selected: _selectedCategory == _categories[index],
                          onSelected: (selected) {
                            setState(() {
                              _selectedCategory = _categories[index];
                              _filterSymbols(_searchController.text);
                            });
                          },
                        ),
                      );
                    },
                  ),
                ),
                const Divider(),
                Expanded(
                  child: ListView.builder(
                    itemCount: _filteredSymbols.length,
                    itemBuilder: (context, index) {
                      final symbol = _filteredSymbols[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        child: ExpansionTile(
                          title: Text(
                            symbol.symbol,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'التفسير:',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    symbol.interpretation,
                                    style: const TextStyle(height: 1.5),
                                  ),
                                  const SizedBox(height: 16),
                                  if (symbol.relatedSymbols.isNotEmpty) ...[
                                    const Text(
                                      'رموز مرتبطة:',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Wrap(
                                      spacing: 8,
                                      children: symbol.relatedSymbols
                                          .map((relatedSymbol) => ActionChip(
                                                label: Text(relatedSymbol),
                                                onPressed: () {
                                                  _searchController.text =
                                                      relatedSymbol;
                                                  _filterSymbols(relatedSymbol);
                                                },
                                              ))
                                          .toList(),
                                    ),
                                  ],
                                  const Divider(),
                                  Wrap(
                                    spacing: 8,
                                    children: symbol.categories
                                        .map((category) => Chip(
                                              label: Text(category),
                                              backgroundColor:
                                                  Colors.teal.shade50,
                                            ))
                                        .toList(),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
