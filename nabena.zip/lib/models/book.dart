class Book {
  final String id;
  final String title;
  final String author;
  final String category;
  final String description;
  final String? coverUrl;
  final String filePath;
  final int totalPages;
  final List<String> tags;

  Book({
    required this.id,
    required this.title,
    required this.author,
    required this.category,
    required this.description,
    this.coverUrl,
    required this.filePath,
    required this.totalPages,
    required this.tags,
  });

  factory Book.fromJson(Map<String, dynamic> json) {
    return Book(
      id: json['id'],
      title: json['title'],
      author: json['author'],
      category: json['category'],
      description: json['description'],
      coverUrl: json['coverUrl'],
      filePath: json['filePath'],
      totalPages: json['totalPages'],
      tags: List<String>.from(json['tags']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'author': author,
      'category': category,
      'description': description,
      'coverUrl': coverUrl,
      'filePath': filePath,
      'totalPages': totalPages,
      'tags': tags,
    };
  }
}
