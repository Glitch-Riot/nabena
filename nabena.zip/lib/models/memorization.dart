class MemorizationTest {
  final String id;
  final String userId;
  final int surahNumber;
  final List<int> verseNumbers;
  final DateTime timestamp;
  final int score;
  final int totalQuestions;
  final Duration timeSpent;

  MemorizationTest({
    required this.id,
    required this.userId,
    required this.surahNumber,
    required this.verseNumbers,
    required this.timestamp,
    required this.score,
    required this.totalQuestions,
    required this.timeSpent,
  });

  double get accuracyPercentage => (score / totalQuestions) * 100;

  factory MemorizationTest.fromJson(Map<String, dynamic> json) {
    return MemorizationTest(
      id: json['id'],
      userId: json['userId'],
      surahNumber: json['surahNumber'],
      verseNumbers: List<int>.from(json['verseNumbers']),
      timestamp: DateTime.parse(json['timestamp']),
      score: json['score'],
      totalQuestions: json['totalQuestions'],
      timeSpent: Duration(seconds: json['timeSpentSeconds']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'surahNumber': surahNumber,
      'verseNumbers': verseNumbers,
      'timestamp': timestamp.toIso8601String(),
      'score': score,
      'totalQuestions': totalQuestions,
      'timeSpentSeconds': timeSpent.inSeconds,
    };
  }
}

class MemorizationProgress {
  final String userId;
  final int surahNumber;
  final List<int> memorizedVerses;
  final DateTime lastReview;
  final int reviewCount;
  final double averageAccuracy;

  MemorizationProgress({
    required this.userId,
    required this.surahNumber,
    required this.memorizedVerses,
    required this.lastReview,
    required this.reviewCount,
    required this.averageAccuracy,
  });

  factory MemorizationProgress.fromJson(Map<String, dynamic> json) {
    return MemorizationProgress(
      userId: json['userId'],
      surahNumber: json['surahNumber'],
      memorizedVerses: List<int>.from(json['memorizedVerses']),
      lastReview: DateTime.parse(json['lastReview']),
      reviewCount: json['reviewCount'],
      averageAccuracy: json['averageAccuracy'].toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'surahNumber': surahNumber,
      'memorizedVerses': memorizedVerses,
      'lastReview': lastReview.toIso8601String(),
      'reviewCount': reviewCount,
      'averageAccuracy': averageAccuracy,
    };
  }

  MemorizationProgress updateWithTestResult(MemorizationTest test) {
    final newReviewCount = reviewCount + 1;
    final newAverageAccuracy =
        ((averageAccuracy * reviewCount) + test.accuracyPercentage) /
            newReviewCount;

    return MemorizationProgress(
      userId: userId,
      surahNumber: surahNumber,
      memorizedVerses: memorizedVerses,
      lastReview: test.timestamp,
      reviewCount: newReviewCount,
      averageAccuracy: newAverageAccuracy,
    );
  }

  bool isVerseMemorized(int verseNumber) {
    return memorizedVerses.contains(verseNumber);
  }

  double getMemorizationPercentage(int totalVerses) {
    return (memorizedVerses.length / totalVerses) * 100;
  }

  bool needsReview() {
    final daysSinceLastReview = DateTime.now().difference(lastReview).inDays;
    if (averageAccuracy < 70) return true;
    if (averageAccuracy < 85) return daysSinceLastReview >= 3;
    if (averageAccuracy < 95) return daysSinceLastReview >= 7;
    return daysSinceLastReview >= 14;
  }
}
