class Athkar {
  final String category;
  final List<Thikr> athkar;

  Athkar({
    required this.category,
    required this.athkar,
  });

  factory Athkar.fromJson(Map<String, dynamic> json) {
    return Athkar(
      category: json['category'],
      athkar: (json['athkar'] as List)
          .map((thikr) => Thikr.fromJson(thikr))
          .toList(),
    );
  }
}

class Thikr {
  final String text;
  final String description;
  final int count;
  final String? source;
  final String? fadl;

  Thikr({
    required this.text,
    required this.description,
    required this.count,
    this.source,
    this.fadl,
  });

  factory Thikr.fromJson(Map<String, dynamic> json) {
    return Thikr(
      text: json['text'],
      description: json['description'],
      count: json['count'],
      source: json['source'],
      fadl: json['fadl'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'text': text,
      'description': description,
      'count': count,
      'source': source,
      'fadl': fadl,
    };
  }
}
