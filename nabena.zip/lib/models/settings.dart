class UserSettings {
  final bool notificationsEnabled;
  final String quranReciter;
  final String calculationMethod;
  final String madhab;
  final double fontSize;
  final bool darkMode;
  final bool autoPlayAthkar;
  final int remainingKhatmahDays;
  final int lastReadPage;
  final List<String> bookmarks;
  final String selectedLanguage;

  UserSettings({
    required this.notificationsEnabled,
    required this.quranReciter,
    required this.calculationMethod,
    required this.madhab,
    required this.fontSize,
    required this.darkMode,
    required this.autoPlayAthkar,
    required this.remainingKhatmahDays,
    required this.lastReadPage,
    required this.bookmarks,
    required this.selectedLanguage,
  });

  UserSettings copyWith({
    bool? notificationsEnabled,
    String? quranReciter,
    String? calculationMethod,
    String? madhab,
    double? fontSize,
    bool? darkMode,
    bool? autoPlayAthkar,
    int? remainingKhatmahDays,
    int? lastReadPage,
    List<String>? bookmarks,
    String? selectedLanguage,
  }) {
    return UserSettings(
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      quranReciter: quranReciter ?? this.quranReciter,
      calculationMethod: calculationMethod ?? this.calculationMethod,
      madhab: madhab ?? this.madhab,
      fontSize: fontSize ?? this.fontSize,
      darkMode: darkMode ?? this.darkMode,
      autoPlayAthkar: autoPlayAthkar ?? this.autoPlayAthkar,
      remainingKhatmahDays: remainingKhatmahDays ?? this.remainingKhatmahDays,
      lastReadPage: lastReadPage ?? this.lastReadPage,
      bookmarks: bookmarks ?? this.bookmarks,
      selectedLanguage: selectedLanguage ?? this.selectedLanguage,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'notificationsEnabled': notificationsEnabled,
      'quranReciter': quranReciter,
      'calculationMethod': calculationMethod,
      'madhab': madhab,
      'fontSize': fontSize,
      'darkMode': darkMode,
      'autoPlayAthkar': autoPlayAthkar,
      'remainingKhatmahDays': remainingKhatmahDays,
      'lastReadPage': lastReadPage,
      'bookmarks': bookmarks,
      'selectedLanguage': selectedLanguage,
    };
  }

  factory UserSettings.fromJson(Map<String, dynamic> json) {
    return UserSettings(
      notificationsEnabled: json['notificationsEnabled'] ?? true,
      quranReciter: json['quranReciter'] ?? 'عبد الباسط عبد الصمد',
      calculationMethod: json['calculationMethod'] ?? 'egyptian',
      madhab: json['madhab'] ?? 'shafi',
      fontSize: json['fontSize']?.toDouble() ?? 18.0,
      darkMode: json['darkMode'] ?? false,
      autoPlayAthkar: json['autoPlayAthkar'] ?? false,
      remainingKhatmahDays: json['remainingKhatmahDays'] ?? 30,
      lastReadPage: json['lastReadPage'] ?? 1,
      bookmarks: List<String>.from(json['bookmarks'] ?? []),
      selectedLanguage: json['selectedLanguage'] ?? 'ar',
    );
  }
}
