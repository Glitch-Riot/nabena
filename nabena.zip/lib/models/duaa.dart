class Duaa {
  final String id;
  final String userId;
  final String content;
  final DateTime createdAt;
  final int prayCount;
  final List<String> categories;
  final bool isAnonymous;
  final bool isApproved;

  Duaa({
    required this.id,
    required this.userId,
    required this.content,
    required this.createdAt,
    this.prayCount = 0,
    required this.categories,
    this.isAnonymous = false,
    this.isApproved = false,
  });

  factory Duaa.fromJson(Map<String, dynamic> json) {
    return Duaa(
      id: json['id'],
      userId: json['userId'],
      content: json['content'],
      createdAt: DateTime.parse(json['createdAt']),
      prayCount: json['prayCount'] ?? 0,
      categories: List<String>.from(json['categories']),
      isAnonymous: json['isAnonymous'] ?? false,
      isApproved: json['isApproved'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'content': content,
      'createdAt': createdAt.toIso8601String(),
      'prayCount': prayCount,
      'categories': categories,
      'isAnonymous': isAnonymous,
      'isApproved': isApproved,
    };
  }

  Duaa copyWith({
    String? id,
    String? userId,
    String? content,
    DateTime? createdAt,
    int? prayCount,
    List<String>? categories,
    bool? isAnonymous,
    bool? isApproved,
  }) {
    return Duaa(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
      prayCount: prayCount ?? this.prayCount,
      categories: categories ?? this.categories,
      isAnonymous: isAnonymous ?? this.isAnonymous,
      isApproved: isApproved ?? this.isApproved,
    );
  }
}
