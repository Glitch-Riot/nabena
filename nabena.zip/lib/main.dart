import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_state_provider.dart';
import 'screens/home_screen.dart';
import 'screens/quran_screen.dart';
import 'screens/athkar_screen.dart';
import 'screens/tasbih_screen.dart';
import 'screens/prayer_times_screen.dart';
import 'screens/qibla_screen.dart';
import 'screens/islamic_library_screen.dart';
import 'screens/khatmah_screen.dart';
import 'screens/dreams_screen.dart';
import 'screens/zakat_calculator_screen.dart';
import 'screens/hadith_screen.dart';
import 'screens/duaa_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => AppStateProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(
      builder: (context, appState, _) {
        if (appState.isLoading) {
          return const MaterialApp(
            home: Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            ),
          );
        }

        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'أنيس المسلم',
          theme: appState.theme,
          locale: Locale(appState.settings.selectedLanguage),
          initialRoute: '/',
          routes: {
            '/': (context) => const HomeScreen(),
            '/quran': (context) => const QuranScreen(),
            '/athkar': (context) => const AthkarScreen(),
            '/tasbih': (context) => const TasbihScreen(),
            '/prayer_times': (context) => const PrayerTimesScreen(),
            '/qibla': (context) => const QiblaScreen(),
            '/library': (context) => const IslamicLibraryScreen(),
            '/khatmah': (context) => const KhatmahScreen(),
            '/dreams': (context) => const DreamsScreen(),
            '/zakat': (context) => const ZakatCalculatorScreen(),
            '/hadith': (context) => const HadithScreen(),
            '/duaa': (context) => const DuaaScreen(),
          },
        );
      },
    );
  }
}
