import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'audio_service.dart';
import 'data_service.dart';
import 'background_service.dart';
import 'notification_service.dart';

class InitializationService {
  static final InitializationService _instance = InitializationService._();
  static InitializationService get instance => _instance;
  bool _isInitialized = false;

  InitializationService._();

  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      // Initialize core services
      await _initializeServices();

      // Preload essential assets
      await _preloadAssets();

      // Initialize background tasks
      await _initializeBackgroundTasks();

      _isInitialized = true;
    } catch (e) {
      print('Initialization error: $e');
      rethrow;
    }
  }

  Future<void> _initializeServices() async {
    // Initialize data service first as other services depend on it
    await DataService.instance.preloadEssentialData();

    // Initialize audio service
    await AudioService.instance.initialize();

    // Initialize notifications
    await NotificationService.instance._initializeNotifications();

    // Initialize background service
    await BackgroundService.instance.initialize();
  }

  Future<void> _preloadAssets() async {
    try {
      // Preload font
      await _cacheFont('Tajawal-Regular');
      await _cacheFont('Tajawal-Bold');

      // Preload essential images
      for (final path in [
        'assets/images/app_icon.png',
        'assets/icons/compass.png',
      ]) {
        final ImageProvider provider = AssetImage(path);
        await precacheImage(provider, null);
      }

      // Load initial JSON data
      await _loadInitialData();
    } catch (e) {
      print('Asset preloading error: $e');
    }
  }

  Future<void> _cacheFont(String fontFamily) async {
    final fontLoader = FontLoader(fontFamily);
    fontLoader.addFont(rootBundle.load('assets/fonts/$fontFamily.ttf'));
    await fontLoader.load();
  }

  Future<void> _loadInitialData() async {
    // Load essential JSON data into memory
    await rootBundle.loadString('assets/data/athkar.json');
    await rootBundle.loadString('assets/data/common_duas.json');

    // Preload first surah
    await rootBundle.loadString('assets/quran/surahs/1.txt');
  }

  Future<void> _initializeBackgroundTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;

    if (notificationsEnabled) {
      await BackgroundService.instance.schedulePrayerTimeUpdates();
      await BackgroundService.instance.scheduleQuranReminder();
      await BackgroundService.instance.scheduleAthkarReminder();
    }
  }

  Future<void> reinitialize() async {
    _isInitialized = false;
    await initialize();
  }

  bool get isInitialized => _isInitialized;
}
