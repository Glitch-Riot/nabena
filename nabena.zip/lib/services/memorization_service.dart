import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/memorization.dart';
import '../models/surah.dart';

class MemorizationService {
  static final MemorizationService _instance = MemorizationService._();
  static MemorizationService get instance => _instance;
  final _uuid = const Uuid();

  MemorizationService._();

  Future<List<MemorizationProgress>> getMemorizationProgress(
      String userId) async {
    final prefs = await SharedPreferences.getInstance();
    final String? data = prefs.getString('memorization_progress_$userId');
    if (data == null) return [];

    final List<dynamic> jsonList = json.decode(data);
    return jsonList.map((json) => MemorizationProgress.fromJson(json)).toList();
  }

  Future<void> saveMemorizationProgress(
    String userId,
    List<MemorizationProgress> progress,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final String data = json.encode(
      progress.map((p) => p.toJson()).toList(),
    );
    await prefs.setString('memorization_progress_$userId', data);
  }

  Future<List<MemorizationTest>> getTestHistory(String userId) async {
    final prefs = await SharedPreferences.getInstance();
    final String? data = prefs.getString('memorization_tests_$userId');
    if (data == null) return [];

    final List<dynamic> jsonList = json.decode(data);
    return jsonList.map((json) => MemorizationTest.fromJson(json)).toList();
  }

  Future<void> saveTest(MemorizationTest test) async {
    final prefs = await SharedPreferences.getInstance();
    final List<MemorizationTest> tests = await getTestHistory(test.userId);
    tests.add(test);

    final String data = json.encode(
      tests.map((t) => t.toJson()).toList(),
    );
    await prefs.setString('memorization_tests_${test.userId}', data);

    // Update progress
    final List<MemorizationProgress> progress =
        await getMemorizationProgress(test.userId);
    final existingProgress = progress.firstWhere(
      (p) => p.surahNumber == test.surahNumber,
      orElse: () => MemorizationProgress(
        userId: test.userId,
        surahNumber: test.surahNumber,
        memorizedVerses: [],
        lastReview: test.timestamp,
        reviewCount: 0,
        averageAccuracy: 0,
      ),
    );

    final updatedProgress = existingProgress.updateWithTestResult(test);
    progress.removeWhere((p) => p.surahNumber == test.surahNumber);
    progress.add(updatedProgress);
    await saveMemorizationProgress(test.userId, progress);
  }

  Future<List<int>> getSuggestedReviewVerses(
    String userId,
    int surahNumber,
    int verseCount,
  ) async {
    final progress = await getMemorizationProgress(userId);
    final surahProgress = progress.firstWhere(
      (p) => p.surahNumber == surahNumber,
      orElse: () => MemorizationProgress(
        userId: userId,
        surahNumber: surahNumber,
        memorizedVerses: [],
        lastReview: DateTime.now(),
        reviewCount: 0,
        averageAccuracy: 0,
      ),
    );

    if (surahProgress.memorizedVerses.isEmpty) {
      return [];
    }

    // Prioritize verses based on review history and accuracy
    final List<int> verses = List.from(surahProgress.memorizedVerses);
    verses.shuffle(); // Randomize order
    return verses.take(verseCount).toList();
  }

  MemorizationTest createTest({
    required String userId,
    required int surahNumber,
    required List<int> verseNumbers,
    required int score,
    required Duration timeSpent,
  }) {
    return MemorizationTest(
      id: _uuid.v4(),
      userId: userId,
      surahNumber: surahNumber,
      verseNumbers: verseNumbers,
      timestamp: DateTime.now(),
      score: score,
      totalQuestions: verseNumbers.length,
      timeSpent: timeSpent,
    );
  }

  Future<void> markVerseAsMemorized(
    String userId,
    int surahNumber,
    int verseNumber,
  ) async {
    final progress = await getMemorizationProgress(userId);
    final existingProgress = progress.firstWhere(
      (p) => p.surahNumber == surahNumber,
      orElse: () => MemorizationProgress(
        userId: userId,
        surahNumber: surahNumber,
        memorizedVerses: [],
        lastReview: DateTime.now(),
        reviewCount: 0,
        averageAccuracy: 0,
      ),
    );

    if (!existingProgress.memorizedVerses.contains(verseNumber)) {
      final updatedVerses = [...existingProgress.memorizedVerses, verseNumber];
      final updatedProgress = MemorizationProgress(
        userId: existingProgress.userId,
        surahNumber: existingProgress.surahNumber,
        memorizedVerses: updatedVerses,
        lastReview: existingProgress.lastReview,
        reviewCount: existingProgress.reviewCount,
        averageAccuracy: existingProgress.averageAccuracy,
      );

      progress.removeWhere((p) => p.surahNumber == surahNumber);
      progress.add(updatedProgress);
      await saveMemorizationProgress(userId, progress);
    }
  }

  Future<Map<int, double>> getOverallProgress(String userId) async {
    final progress = await getMemorizationProgress(userId);
    final Map<int, double> overallProgress = {};

    for (var surahProgress in progress) {
      final Surah? surah = await _getSurahInfo(surahProgress.surahNumber);
      if (surah != null) {
        final percentage = surahProgress.getMemorizationPercentage(
          surah.numberOfAyahs,
        );
        overallProgress[surahProgress.surahNumber] = percentage;
      }
    }

    return overallProgress;
  }

  Future<Surah?> _getSurahInfo(int surahNumber) async {
    // This should be implemented to get Surah information from your data source
    // For now, returning null as placeholder
    return null;
  }

  Future<List<int>> getSurahsNeedingReview(String userId) async {
    final progress = await getMemorizationProgress(userId);
    return progress
        .where((p) => p.needsReview())
        .map((p) => p.surahNumber)
        .toList();
  }
}
