import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'notification_service.dart';

class PrayerService {
  static final PrayerService _instance = PrayerService._();
  static PrayerService get instance => _instance;
  
  PrayerService._();

  Future<Position> _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Location services are disabled.');
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Location permissions are denied');
      }
    }

    return await Geolocator.getCurrentPosition();
  }

  Future<PrayerTimes> getPrayerTimes() async {
    final Position position = await _getCurrentLocation();
    
    final coordinates = Coordinates(position.latitude, position.longitude);
    final params = CalculationMethod.egyptian.getParameters();
    params.madhab = Madhab.shafi;
    
    final date = DateTime.now();
    final prayerTimes = PrayerTimes(coordinates, date, params);
    
    return prayerTimes;
  }

  Future<void> schedulePrayerNotifications() async {
    final prayerTimes = await getPrayerTimes();
    final prayers = {
      'الفجر': prayerTimes.fajr,
      'الظهر': prayerTimes.dhuhr,
      'العصر': prayerTimes.asr,
      'المغرب': prayerTimes.maghrib,
      'العشاء': prayerTimes.isha,
    };

    for (var prayer in prayers.entries) {
      if (prayer.value.isAfter(DateTime.now())) {
        await NotificationService.instance.schedulePrayerReminder(
          prayer.key,
          prayer.value,
        );
      }
    }
  }

  String formatPrayerTime(DateTime? time) {
    if (time == null) return '--:--';
    return DateFormat.jm().format(time);
  }

  Future<String> getQiblaDirection() async {
    final Position position = await _getCurrentLocation();
    final coordinates = Coordinates(position.latitude, position.longitude);
    final qibla = Qibla(coordinates);
    return '${qibla.direction.toStringAsFixed(2)}°';
  }
}