import 'package:workmanager/workmanager.dart';
import 'package:shared_preferences.dart';
import '../services/notification_service.dart';
import '../services/prayer_service.dart';

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    switch (task) {
      case 'updatePrayerTimes':
        await _updatePrayerTimes();
        break;
      case 'dailyQuranReminder':
        await _sendQuranReminder();
        break;
      case 'dailyAthkarReminder':
        await _sendAthkarReminder();
        break;
    }
    return true;
  });
}

class BackgroundService {
  static final BackgroundService _instance = BackgroundService._();
  static BackgroundService get instance => _instance;

  BackgroundService._();

  Future<void> initialize() async {
    await Workmanager().initialize(
      callbackDispatcher,
      isInDebugMode: false,
    );
  }

  Future<void> schedulePrayerTimeUpdates() async {
    await Workmanager().registerPeriodicTask(
      'updatePrayerTimes',
      'updatePrayerTimes',
      frequency: const Duration(hours: 12),
      constraints: Constraints(
        networkType: NetworkType.connected,
      ),
    );
  }

  Future<void> scheduleQuranReminder() async {
    await Workmanager().registerPeriodicTask(
      'dailyQuranReminder',
      'dailyQuranReminder',
      frequency: const Duration(days: 1),
    );
  }

  Future<void> scheduleAthkarReminder() async {
    await Workmanager().registerPeriodicTask(
      'dailyAthkarReminder',
      'dailyAthkarReminder',
      frequency: const Duration(days: 1),
    );
  }
}

Future<void> _updatePrayerTimes() async {
  final prefs = await SharedPreferences.getInstance();
  final notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;

  if (notificationsEnabled) {
    await PrayerService.instance.schedulePrayerNotifications();
  }
}

Future<void> _sendQuranReminder() async {
  final prefs = await SharedPreferences.getInstance();
  final notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
  final quranReminderTime = prefs.getString('quran_reminder_time');

  if (notificationsEnabled && quranReminderTime != null) {
    final lastPage = prefs.getInt('last_read_page') ?? 1;
    await NotificationService.instance.scheduleQuranKhatmahReminder(
      'تذكير بقراءة القرآن',
      'لا تنس نصيبك من تلاوة القرآن اليوم - آخر قراءة: صفحة $lastPage',
      DateTime.now(),
    );
  }
}

Future<void> _sendAthkarReminder() async {
  final prefs = await SharedPreferences.getInstance();
  final notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;

  if (notificationsEnabled) {
    final now = DateTime.now();
    final isMorning = now.hour >= 4 && now.hour < 11;

    await NotificationService.instance.scheduleAthkarReminder(
      isMorning ? 'أذكار الصباح' : 'أذكار المساء',
      isMorning ? 'حان وقت أذكار الصباح' : 'حان وقت أذكار المساء',
      now,
    );
  }
}
