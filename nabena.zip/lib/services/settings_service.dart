import 'package:shared_preferences/shared_preferences.dart';
import '../models/settings.dart';

class SettingsService {
  static final SettingsService _instance = SettingsService._();
  static SettingsService get instance => _instance;

  SettingsService._();

  Future<UserSettings> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();

    return UserSettings(
      notificationsEnabled: prefs.getBool('notifications_enabled') ?? true,
      quranReciter: prefs.getString('quran_reciter') ?? 'عبد الباسط عبد الصمد',
      calculationMethod: prefs.getString('calculation_method') ?? 'egyptian',
      madhab: prefs.getString('madhab') ?? 'shafi',
      fontSize: prefs.getDouble('font_size') ?? 18.0,
      darkMode: prefs.getBool('dark_mode') ?? false,
      autoPlayAthkar: prefs.getBool('auto_play_athkar') ?? false,
      remainingKhatmahDays: prefs.getInt('khatmah_days') ?? 30,
      lastReadPage: prefs.getInt('last_read_page') ?? 1,
      bookmarks: _getBookmarksList(prefs),
      selectedLanguage: prefs.getString('selected_language') ?? 'ar',
    );
  }

  List<String> _getBookmarksList(SharedPreferences prefs) {
    return prefs.getStringList('bookmarks') ?? [];
  }

  Future<void> saveSettings(UserSettings settings) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool('notifications_enabled', settings.notificationsEnabled);
    await prefs.setString('quran_reciter', settings.quranReciter);
    await prefs.setString('calculation_method', settings.calculationMethod);
    await prefs.setString('madhab', settings.madhab);
    await prefs.setDouble('font_size', settings.fontSize);
    await prefs.setBool('dark_mode', settings.darkMode);
    await prefs.setBool('auto_play_athkar', settings.autoPlayAthkar);
    await prefs.setInt('khatmah_days', settings.remainingKhatmahDays);
    await prefs.setInt('last_read_page', settings.lastReadPage);
    await prefs.setStringList('bookmarks', settings.bookmarks);
    await prefs.setString('selected_language', settings.selectedLanguage);
  }

  Future<void> updateSetting(String key, dynamic value) async {
    final prefs = await SharedPreferences.getInstance();

    switch (value) {
      case bool _:
        await prefs.setBool(key, value);
      case String _:
        await prefs.setString(key, value);
      case int _:
        await prefs.setInt(key, value);
      case double _:
        await prefs.setDouble(key, value);
      case List _:
        if (value is List<String>) {
          await prefs.setStringList(key, value);
        }
    }
  }

  Future<void> clearSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  Future<void> addBookmark(String bookmark) async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarks = _getBookmarksList(prefs);
    if (!bookmarks.contains(bookmark)) {
      bookmarks.add(bookmark);
      await prefs.setStringList('bookmarks', bookmarks);
    }
  }

  Future<void> removeBookmark(String bookmark) async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarks = _getBookmarksList(prefs);
    bookmarks.remove(bookmark);
    await prefs.setStringList('bookmarks', bookmarks);
  }
}
