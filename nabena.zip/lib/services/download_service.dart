import 'package:http/http.dart' as http;
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import '../services/data_service.dart';

enum DownloadType {
  surah,
  thikr,
  book,
  hadith,
}

class DownloadItem {
  final String id;
  final String title;
  final DownloadType type;
  final String url;
  final int size;
  bool isDownloaded;
  double progress;

  DownloadItem({
    required this.id,
    required this.title,
    required this.type,
    required this.url,
    required this.size,
    this.isDownloaded = false,
    this.progress = 0.0,
  });
}

class DownloadService {
  static final DownloadService _instance = DownloadService._();
  static DownloadService get instance => _instance;
  final DataService _dataService = DataService.instance;
  final Map<String, DownloadItem> _activeDownloads = {};
  final List<Function(DownloadItem)> _listeners = [];

  DownloadService._();

  void addListener(Function(DownloadItem) listener) {
    _listeners.add(listener);
  }

  void removeListener(Function(DownloadItem) listener) {
    _listeners.remove(listener);
  }

  void _notifyListeners(DownloadItem item) {
    for (var listener in _listeners) {
      listener(item);
    }
  }

  Future<String> get _downloadDirectory async {
    final appDir = await getApplicationDocumentsDirectory();
    final downloadDir = Directory(path.join(appDir.path, 'downloads'));
    if (!await downloadDir.exists()) {
      await downloadDir.create(recursive: true);
    }
    return downloadDir.path;
  }

  Future<String> _getFilePath(DownloadItem item) async {
    final dir = await _downloadDirectory;
    return path.join(dir, '${item.type.toString().split('.').last}_${item.id}');
  }

  Future<bool> isDownloaded(DownloadItem item) async {
    final filePath = await _getFilePath(item);
    return File(filePath).exists();
  }

  Future<void> download(DownloadItem item) async {
    if (_activeDownloads.containsKey(item.id)) return;

    _activeDownloads[item.id] = item;
    _notifyListeners(item);

    try {
      final response = await http.get(
        Uri.parse(item.url),
        headers: {'Range': 'bytes=0-'},
      ).timeout(const Duration(minutes: 30));

      if (response.statusCode == 200 || response.statusCode == 206) {
        final filePath = await _getFilePath(item);
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);

        // Save metadata in database
        await _dataService.saveDownload(
          item.id,
          item.type.toString(),
          filePath,
        );

        item.isDownloaded = true;
        item.progress = 1.0;
      } else {
        item.progress = 0.0;
        throw Exception('Download failed: ${response.statusCode}');
      }
    } catch (e) {
      item.progress = 0.0;
      rethrow;
    } finally {
      _activeDownloads.remove(item.id);
      _notifyListeners(item);
    }
  }

  Future<void> downloadWithProgress(DownloadItem item) async {
    if (_activeDownloads.containsKey(item.id)) return;

    _activeDownloads[item.id] = item;
    _notifyListeners(item);

    try {
      final client = http.Client();
      final request = http.Request('GET', Uri.parse(item.url));
      final response = await client.send(request);

      if (response.statusCode == 200) {
        final filePath = await _getFilePath(item);
        final file = File(filePath);
        final sink = file.openWrite();

        int received = 0;
        final total = response.contentLength ?? item.size;

        await for (final chunk in response.stream) {
          sink.add(chunk);
          received += chunk.length;
          item.progress = received / total;
          _notifyListeners(item);
        }

        await sink.close();

        // Save metadata in database
        await _dataService.saveDownload(
          item.id,
          item.type.toString(),
          filePath,
        );

        item.isDownloaded = true;
        item.progress = 1.0;
      } else {
        item.progress = 0.0;
        throw Exception('Download failed: ${response.statusCode}');
      }
    } catch (e) {
      item.progress = 0.0;
      rethrow;
    } finally {
      _activeDownloads.remove(item.id);
      _notifyListeners(item);
    }
  }

  Future<void> cancelDownload(String itemId) async {
    final item = _activeDownloads[itemId];
    if (item != null) {
      _activeDownloads.remove(itemId);
      item.progress = 0.0;
      _notifyListeners(item);

      // Delete partially downloaded file
      final filePath = await _getFilePath(item);
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
      }
    }
  }

  Future<void> deleteDownload(DownloadItem item) async {
    final filePath = await _getFilePath(item);
    final file = File(filePath);
    if (await file.exists()) {
      await file.delete();
    }

    await _dataService.deleteDownload(item.id, item.type.toString());

    item.isDownloaded = false;
    item.progress = 0.0;
    _notifyListeners(item);
  }

  Future<List<DownloadItem>> getDownloadedItems(DownloadType type) async {
    final items = await _dataService.getDownloadedItems(type.toString());
    return items
        .map((item) => DownloadItem(
              id: item['id'],
              title: item['title'] ?? '',
              type: type,
              url: item['url'] ?? '',
              size: item['size'] ?? 0,
              isDownloaded: true,
              progress: 1.0,
            ))
        .toList();
  }

  Future<int> getTotalDownloadSize() async {
    final dir = await _downloadDirectory;
    int total = 0;
    await for (final file in Directory(dir).list(recursive: true)) {
      if (file is File) {
        total += await file.length();
      }
    }
    return total;
  }

  Future<void> clearAllDownloads() async {
    final dir = await _downloadDirectory;
    await Directory(dir).delete(recursive: true);
    await _dataService.clearOldData();
  }

  Map<String, DownloadItem> get activeDownloads =>
      Map.unmodifiable(_activeDownloads);
}
