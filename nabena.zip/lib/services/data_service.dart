import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:flutter/services.dart';

class DataService {
  static final DataService _instance = DataService._();
  static DataService get instance => _instance;
  Database? _database;

  DataService._();

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'nabena.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDatabase,
    );
  }

  Future<void> _createDatabase(Database db, int version) async {
    await db.execute('''
      CREATE TABLE downloads (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        content TEXT NOT NULL,
        timestamp INTEGER NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE bookmarks (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        reference TEXT NOT NULL,
        title TEXT NOT NULL,
        timestamp INTEGER NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE recent_reads (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        reference TEXT NOT NULL,
        title TEXT NOT NULL,
        last_position TEXT NOT NULL,
        timestamp INTEGER NOT NULL
      )
    ''');
  }

  Future<void> saveDownload(String id, String type, String content) async {
    final db = await database;
    await db.insert(
      'downloads',
      {
        'id': id,
        'type': type,
        'content': content,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<String?> getDownloadedContent(String id, String type) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'downloads',
      where: 'id = ? AND type = ?',
      whereArgs: [id, type],
    );

    if (maps.isEmpty) return null;
    return maps.first['content'] as String;
  }

  Future<void> deleteDownload(String id, String type) async {
    final db = await database;
    await db.delete(
      'downloads',
      where: 'id = ? AND type = ?',
      whereArgs: [id, type],
    );
  }

  Future<List<Map<String, dynamic>>> getDownloadedItems(String type) async {
    final db = await database;
    return await db.query(
      'downloads',
      where: 'type = ?',
      whereArgs: [type],
      orderBy: 'timestamp DESC',
    );
  }

  Future<void> addBookmark(String type, String reference, String title) async {
    final db = await database;
    await db.insert(
      'bookmarks',
      {
        'id': '${type}_$reference',
        'type': type,
        'reference': reference,
        'title': title,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> removeBookmark(String type, String reference) async {
    final db = await database;
    await db.delete(
      'bookmarks',
      where: 'id = ?',
      whereArgs: ['${type}_$reference'],
    );
  }

  Future<List<Map<String, dynamic>>> getBookmarks(String type) async {
    final db = await database;
    return await db.query(
      'bookmarks',
      where: 'type = ?',
      whereArgs: [type],
      orderBy: 'timestamp DESC',
    );
  }

  Future<void> updateRecentRead(
    String type,
    String reference,
    String title,
    String lastPosition,
  ) async {
    final db = await database;
    await db.insert(
      'recent_reads',
      {
        'id': '${type}_$reference',
        'type': type,
        'reference': reference,
        'title': title,
        'last_position': lastPosition,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getRecentReads(String type) async {
    final db = await database;
    return await db.query(
      'recent_reads',
      where: 'type = ?',
      whereArgs: [type],
      orderBy: 'timestamp DESC',
      limit: 10,
    );
  }

  Future<String?> getLastPosition(String type, String reference) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'recent_reads',
      where: 'id = ?',
      whereArgs: ['${type}_$reference'],
    );

    if (maps.isEmpty) return null;
    return maps.first['last_position'] as String;
  }

  Future<void> preloadEssentialData() async {
    try {
      // Preload short surahs for offline access
      final List<String> shortSurahs = [
        '1',
        '112',
        '113',
        '114'
      ]; // Al-Fatiha and last 3 surahs
      for (var surahNumber in shortSurahs) {
        final content =
            await rootBundle.loadString('assets/quran/surahs/$surahNumber.txt');
        await saveDownload('surah_$surahNumber', 'quran', content);
      }

      // Preload morning and evening athkar
      final athkarContent =
          await rootBundle.loadString('assets/data/athkar.json');
      await saveDownload('athkar_essential', 'athkar', athkarContent);

      // Preload common duas
      final duasContent =
          await rootBundle.loadString('assets/data/common_duas.json');
      await saveDownload('common_duas', 'duas', duasContent);
    } catch (e) {
      // Handle preloading errors
      print('Error preloading essential data: $e');
    }
  }

  Future<void> clearOldData() async {
    final db = await database;
    final thirtyDaysAgo = DateTime.now()
        .subtract(const Duration(days: 30))
        .millisecondsSinceEpoch;

    await db.delete(
      'downloads',
      where: 'timestamp < ?',
      whereArgs: [thirtyDaysAgo],
    );
  }

  Future<int> getDatabaseSize() async {
    final db = await database;
    final List<Map<String, dynamic>> result = await db.rawQuery(
        'SELECT page_count * page_size as size FROM pragma_page_count, pragma_page_size');
    return result.first['size'] as int;
  }
}
