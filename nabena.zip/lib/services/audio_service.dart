import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as path;

class AudioService {
  static final AudioService _instance = AudioService._();
  static AudioService get instance => _instance;
  final AudioPlayer _player = AudioPlayer();
  bool _isInitialized = false;
  String? _currentlyPlaying;

  AudioService._();

  Future<void> initialize() async {
    if (!_isInitialized) {
      await _createAudioCache();
      _isInitialized = true;
    }
  }

  Future<void> _createAudioCache() async {
    final cacheDir = await getApplicationDocumentsDirectory();
    final audioCacheDir = Directory(path.join(cacheDir.path, 'audio_cache'));
    if (!await audioCacheDir.exists()) {
      await audioCacheDir.create(recursive: true);
    }
  }

  Future<String> _getCachedPath(String url) async {
    final cacheDir = await getApplicationDocumentsDirectory();
    final fileName = path.basename(url);
    return path.join(cacheDir.path, 'audio_cache', fileName);
  }

  Future<bool> isAudioCached(String url) async {
    final cachePath = await _getCachedPath(url);
    return File(cachePath).exists();
  }

  Future<void> cacheAudio(String url) async {
    if (await isAudioCached(url)) return;

    final cachePath = await _getCachedPath(url);
    final response = await http.get(Uri.parse(url));
    await File(cachePath).writeAsBytes(response.bodyBytes);
  }

  Future<void> play({
    required String url,
    bool isLocalAsset = false,
    bool autoCache = true,
  }) async {
    if (_currentlyPlaying == url && _player.playing) {
      await pause();
      return;
    }

    String audioSource;
    if (isLocalAsset) {
      audioSource = url;
      await _player.setAsset(audioSource);
    } else {
      if (autoCache && !await isAudioCached(url)) {
        await cacheAudio(url);
      }
      audioSource = await _getCachedPath(url);
      if (await File(audioSource).exists()) {
        await _player.setFilePath(audioSource);
      } else {
        await _player.setUrl(url);
      }
    }

    _currentlyPlaying = url;
    await _player.play();
  }

  Future<void> pause() async {
    await _player.pause();
  }

  Future<void> resume() async {
    await _player.play();
  }

  Future<void> stop() async {
    await _player.stop();
    _currentlyPlaying = null;
  }

  Future<void> seekTo(Duration position) async {
    await _player.seek(position);
  }

  Future<void> setVolume(double volume) async {
    await _player.setVolume(volume);
  }

  Future<void> setSpeed(double speed) async {
    await _player.setSpeed(speed);
  }

  Stream<Duration?> get positionStream => _player.positionStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<PlayerState> get playerStateStream => _player.playerStateStream;

  bool get isPlaying => _player.playing;
  String? get currentlyPlaying => _currentlyPlaying;

  Future<void> clearCache() async {
    final cacheDir = await getApplicationDocumentsDirectory();
    final audioCacheDir = Directory(path.join(cacheDir.path, 'audio_cache'));
    if (await audioCacheDir.exists()) {
      await audioCacheDir.delete(recursive: true);
      await _createAudioCache();
    }
  }

  Future<int> getCacheSize() async {
    final cacheDir = await getApplicationDocumentsDirectory();
    final audioCacheDir = Directory(path.join(cacheDir.path, 'audio_cache'));
    if (!await audioCacheDir.exists()) return 0;

    int totalSize = 0;
    await for (final file in audioCacheDir.list(recursive: true)) {
      if (file is File) {
        totalSize += await file.length();
      }
    }
    return totalSize;
  }

  Future<void> dispose() async {
    await _player.dispose();
  }

  // Specific methods for Quran recitation
  Future<void> playQuranAudio({
    required String reciter,
    required int surahNumber,
    required int verseNumber,
    bool repeat = false,
  }) async {
    final String url =
        'assets/audio/quran/$reciter/$surahNumber/$verseNumber.mp3';
    await play(url: url, isLocalAsset: true);
    if (repeat) {
      _player.setLoopMode(LoopMode.one);
    }
  }

  // Specific methods for Athkar audio
  Future<void> playThikrAudio({
    required String category,
    required String thikrId,
  }) async {
    final String url = 'assets/audio/athkar/$category/$thikrId.mp3';
    await play(url: url, isLocalAsset: true);
  }

  // Method for auto-repeat functionality
  Future<void> setRepeatRange({
    required Duration start,
    required Duration end,
    required int repeatCount,
  }) async {
    _player.setClip(start: start, end: end);
    for (var i = 0; i < repeatCount; i++) {
      await _player.seek(start);
      await _player.play();
      while (_player.position < end) {
        await Future.delayed(const Duration(milliseconds: 100));
      }
    }
    _player.setClip();
  }
}
