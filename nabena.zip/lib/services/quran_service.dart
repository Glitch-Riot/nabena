import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/surah.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class QuranService {
  static final QuranService _instance = QuranService._();
  static QuranService get instance => _instance;
  final AudioPlayer _audioPlayer = AudioPlayer();
  
  QuranService._();

  Future<List<Surah>> loadSurahs() async {
    final String data = await rootBundle.loadString('assets/quran/surah_list.json');
    final List<dynamic> jsonList = json.decode(data);
    return jsonList.map((json) => Surah.fromJson(json)).toList();
  }

  Future<String> loadSurahContent(int surahNumber) async {
    return await rootBundle.loadString('assets/quran/surahs/$surahNumber.txt');
  }

  Future<void> playAudio(String reciter, int surahNumber) async {
    final String audioUrl = 'assets/audio/$reciter/$surahNumber.mp3';
    await _audioPlayer.setAsset(audioUrl);
    await _audioPlayer.play();
  }

  Future<void> pauseAudio() async {
    await _audioPlayer.pause();
  }

  Future<void> stopAudio() async {
    await _audioPlayer.stop();
  }

  Future<void> saveBookmark(int surahNumber, int ayahNumber) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('lastSurah', surahNumber);
    await prefs.setInt('lastAyah', ayahNumber);
  }

  Future<Map<String, int>> getLastBookmark() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'surahNumber': prefs.getInt('lastSurah') ?? 1,
      'ayahNumber': prefs.getInt('lastAyah') ?? 1,
    };
  }

  Future<void> saveMemorizationProgress(int surahNumber, List<int> memorizedAyahs) async {
    final prefs = await SharedPreferences.getInstance();
    final String key = 'memorization_surah_$surahNumber';
    await prefs.setString(key, json.encode(memorizedAyahs));
  }

  Future<List<int>> getMemorizationProgress(int surahNumber) async {
    final prefs = await SharedPreferences.getInstance();
    final String key = 'memorization_surah_$surahNumber';
    final String? data = prefs.getString(key);
    if (data == null) return [];
    return List<int>.from(json.decode(data));
  }
}